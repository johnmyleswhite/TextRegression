* Improve devtools usage.
* Allow greater configuration of analysis.
* Expand on returned outputs.
* Use heuristics to control cross-validation.

* Figure out why glmnet used to tolerate y being a matrix and now requires a vector.
* Add mechanism to predict from novel text.
