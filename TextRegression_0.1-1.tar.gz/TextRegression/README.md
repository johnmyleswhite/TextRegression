# Introduction
Here's the TextRegression package, which makes it easy to predict continuous
outputs using text inputs.


