#!/bin/bash

ftp ftp://cran.r-project.org
# cd incoming
# bin
# put TextRegression_*.tar.gz
# exit
