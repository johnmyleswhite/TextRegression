* Improve devtools usage.
* Allow greater configuration of analysis.
* Expand on returned outputs.
* Use heuristics to control cross-validation.

